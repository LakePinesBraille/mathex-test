// import * as BrailleModule from "@cadenceos/core";

const settings = () => { return false; }
window.BrailleModule = { settings: settings };
